# Nacitanie R balika potrebneho pre digitalizaciu landmarkov 
library(geomorph)

files_names<-list.files(pattern = "[jJ][pP][gG]")
files_names
digitize2d(files_names,7,1,"nove_suradnice")
